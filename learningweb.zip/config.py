# -*- coding: <utf-8> -*-
HOST = 'localhost'
USER = 'root'
PASSWORD = '123456'
DATABASE = 'learningweb_db'
PORT = '3306'

